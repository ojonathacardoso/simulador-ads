
package Simulador;

import java.util.ArrayList;

public class Simulador {
    
    public Simulador() {
        
    }
    
    public void simularChamados(ArrayList chamados) {
    
        // Percorrer chamados
        // Usar as probabilidades de analistas pra definir cada analista
        // Usar as probabilidades de tempo pra definir o tempo em dias que levou cada chamado
        // Jogar os chamados (setor, urgencia, analista, tempo) em um arquivo txt ou csv 
        
    }
    
}
